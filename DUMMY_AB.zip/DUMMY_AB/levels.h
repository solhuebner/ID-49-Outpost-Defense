#ifndef LEVELS_H
#define LEVELS_H

#include <Arduino.h>
#include "globals.h"

void checkCollisions()
{
  
}

#endif
